#include <stdio.h>
#include <stdlib.h>

void buscar(int limite_inferior, int limite_superior, int *numero_intentos, int *el_programa_ha_adivinado_el_numero, int *el_jugador_ha_hecho_trampa);

int main()
{

    int el_programa_ha_adivinado_el_numero = 0, el_jugador_ha_hecho_trampa = 0, limite_inferior = 0, limite_superior = 100, numero_intentos = 1;

    printf("¡Piensa un número entre %d y %d!\n", limite_inferior, limite_superior);

    buscar(limite_inferior, limite_superior, &numero_intentos, &el_programa_ha_adivinado_el_numero, &el_jugador_ha_hecho_trampa);

    if (el_jugador_ha_hecho_trampa == 1)
    {
        printf("\nMientes! Ya no juego más contigo.\n");
    }

    if (el_programa_ha_adivinado_el_numero == 1)
    {
        printf("\nYeah! lo he adivinado. He necesitado %d intentos.\n", numero_intentos);
    }

    return 0;
}

void buscar(int limite_inferior, int limite_superior, int *numero_intentos, int *el_programa_ha_adivinado_el_numero, int *el_jugador_ha_hecho_trampa)
{

    int punto_medio_del_intervalo = (limite_inferior + limite_superior) / 2;

    if ((limite_superior - limite_inferior) == 1)
    {
        *el_jugador_ha_hecho_trampa = 1;
    }
    else
    {
        char contestacion = '0';

        printf("\n¿es tu número mayor (>), igual (=), o menor (<) que %d? Por favor responde con <, =, >: ", punto_medio_del_intervalo);

        while (!(contestacion == '<' || contestacion == '=' || contestacion == '>'))
        {
            scanf("%c", &contestacion);
        }

        switch (contestacion)
        {
        case '<':
            limite_superior = punto_medio_del_intervalo;
            break;

        case '=':
            *el_programa_ha_adivinado_el_numero = 1;
            break;

        case '>':
            limite_inferior = punto_medio_del_intervalo;
            break;
        }

        (*numero_intentos)++;
    }

    if (!(*el_programa_ha_adivinado_el_numero == 1 || *el_jugador_ha_hecho_trampa == 1))
        buscar(limite_inferior, limite_superior, numero_intentos, el_programa_ha_adivinado_el_numero, el_jugador_ha_hecho_trampa);
}