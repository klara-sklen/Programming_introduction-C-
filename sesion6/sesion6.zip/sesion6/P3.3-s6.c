#include <stdio.h>

void representarObjeto(int ultimo_objeto);

void representarInventarioActual(int ultimo_objeto);

void imprimeMenu(int *opcion_del_menu);

void representarObjeto(int ultimo_objeto);

void bienvenida();

int main()
{
    char seguir_explorando = '0';

    int opcion_del_menu,
        ultimo_objeto,
        numero_de_objetos_recogidos = 0,
        veces_explorado_bosque = 0,
        veces_explorado_castillo = 0,
        veces_explorado_pueblo = 0;

    while (!(seguir_explorando == 'n'))
    {
        seguir_explorando = '0';

        imprimeMenu(&opcion_del_menu);

        switch (opcion_del_menu)
        {
        case '1':
            printf("Exploras el bosque... encuentras una ");
            representarObjeto(1);
            printf(".\n");
            numero_de_objetos_recogidos++;
            ultimo_objeto = 1;
            veces_explorado_bosque++;
            break;

        case '2':
            printf("Paseas por el pueblo... consigues una ");
            representarObjeto(2);
            printf(".\n");
            numero_de_objetos_recogidos++;
            veces_explorado_castillo++;
            ultimo_objeto = 2;
            break;

        case '3':
            printf("Paseas por el pueblo... consigues una ");
            representarObjeto(3);
            printf(".\n");
            numero_de_objetos_recogidos++;
            ultimo_objeto = 3;
            veces_explorado_pueblo++;

            break;
        }

        representarInventarioActual(ultimo_objeto);

        while (!(seguir_explorando == 's' || seguir_explorando == 'n'))
        {
            printf("¿Deseas seguir explorando? (s/n)\n");
            scanf(" %c", &seguir_explorando);
        }
    }

    printf("\n=== Fin del juego ===\n");
    printf("Has recogido un total de %d objetos.\n", numero_de_objetos_recogidos);
    printf("Tu último objeto fue:");
    representarObjeto(ultimo_objeto);
    printf(".\n");

    printf("\n--- Estadísticas de exploración ---\n");
    printf("Veces que exploraste el bosque: %d\n", veces_explorado_bosque);
    printf("Veces que exploraste el castillo: %d\n", veces_explorado_castillo);
    printf("Veces que exploraste el pueblo: %d\n", veces_explorado_pueblo);
    return 0;
}

void representarObjeto(int ultimo_objeto)
{
    switch (ultimo_objeto)
    {
    case '1':
        printf("espada oxidada");
        break;
    case '2':
        printf("corona dorada");
        break;
    case '3':
        printf("bolsa de monedas");
        break;
    default:
        printf("nada");
        break;
    }
}

void representarInventarioActual(int ultimo_objeto)
{
    printf("\nTu inventario actual contiene: ");
    representarObjeto(ultimo_objeto);
    printf("\n");
}

void imprimeMenu(int *opcion_del_menu)
{
    printf("¿A dónde deseas ir?\n");
    printf("1. Bosque\n");
    printf("2. Castillo\n");
    printf("3. Pueblo\n");
    printf("Elige un número: ");

    scanf("%d", opcion_del_menu);
}

void bienvenida()
{
    printf("==============================\n");
    printf("   BIENVENIDO A LA AVENTURA   \n");
    printf("==============================\n");
}