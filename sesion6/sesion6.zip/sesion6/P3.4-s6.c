#include <stdio.h>

void mostrarSumaTotal(int suma_numeros_pares, int suma_numeros_impares);

void sumarNumeros(int numero_escaneado, int *suma_numeros_pares, int *suma_numeros_impares);

int main()
{
    int numero_escaneado = 1, suma_numeros_pares, suma_numeros_impares;

    while (numero_escaneado != 0) {
        printf("Introduzca un número (si desea cerrar el programa, escriba 0).\n");
        scanf("%d", &numero_escaneado);

        sumarNumeros(numero_escaneado, &suma_numeros_pares, &suma_numeros_impares);

        mostrarSumaTotal(suma_numeros_pares, suma_numeros_impares);
    }

    return 0;
}

void mostrarSumaTotal(int suma_numeros_pares, int suma_numeros_impares) {
    printf("[SUMA TOTAL] Números pares: %d // Números impares %d\n", suma_numeros_pares, suma_numeros_impares);
}

void sumarNumeros(int numero_escaneado, int *suma_numeros_pares, int *suma_numeros_impares)
{
    if ((numero_escaneado % 2) == 0)
        *suma_numeros_pares = *suma_numeros_pares + numero_escaneado;
    else
        *suma_numeros_impares = *suma_numeros_impares + numero_escaneado;
}