#include <stdio.h>

int maximoComunDivisor(int numero_1, int numero_2);

int maximoComunDivisor(int numero_1, int numero_2);

void preguntarValores(int *numero_1, int *numero_2);

void imprimeMenu(char *opcion_del_menu);

int main()
{
    int numero_1, numero_2, el_usuario_ha_pedido_salir_del_programa = 0;
    char opcion_del_menu;

    preguntarValores(&numero_1, &numero_2);

    while (el_usuario_ha_pedido_salir_del_programa == 0)
    {
        imprimeMenu(&opcion_del_menu);

        switch (opcion_del_menu)
        {
        case 'A':
            printf("El mínimo común múltiplo de %d y %d es: %d\n\n", numero_1, numero_2, minimoComunMultiplo(numero_1, numero_2));
            break;

        case 'B':
            printf("El máximo común divisor de %d y %d es: %d\n\n", numero_1, numero_2, maximoComunDivisor(numero_1, numero_2));
            break;

        case 'C':
            el_usuario_ha_pedido_salir_del_programa = 1;
            break;
        }
    }

    return 0;
}

int maximoComunDivisor(int numero_1, int numero_2)
{
    int mcd_numero_1 = numero_1, mcd_numero_2 = numero_2, mcd_caja_temporal;

    while (!(mcd_numero_2 == 0))
    {
        mcd_caja_temporal = mcd_numero_2;
        mcd_numero_2 = mcd_numero_1 % mcd_numero_2;
        mcd_numero_1 = mcd_caja_temporal;
    }

    return mcd_numero_1;
}

int minimoComunMultiplo(int numero_1, int numero_2)
{
    int minimo_mcm = 0, maximo_mcm = numero_1 * numero_2;

    for (int factor_numero_1; factor_numero_1 * numero_1 <= maximo_mcm; factor_numero_1++)
    {
        for (int factor_numero_2; factor_numero_2 * numero_2 <= maximo_mcm; factor_numero_2++)
        {
            if ((minimo_mcm == 0) && (factor_numero_1 * numero_1 == factor_numero_2 * numero_2))
            {
                minimo_mcm = factor_numero_1 * numero_1;
            }
        }
    }

    if (minimo_mcm == 0)
    {
        minimo_mcm = maximo_mcm;
    }

    return minimo_mcm;
}

void preguntarValores(int *numero_1, int *numero_2)
{
    printf("\nIntroduzca el primer número: ");
    scanf("%d", numero_1);

    printf("\nIntroduzca el segundo número: ");
    scanf("%d", numero_2);
}

void imprimeMenu(char *opcion_del_menu)
{
    *opcion_del_menu = '0';

    printf("¿Qué operación quieres realizar con los números?\n");
    printf("A) Calcular el MCM\n");
    printf("B) Calcular el MCD\n");
    printf("C) Salir del programa\n");

    // Añadimos el espacio para que no considere el salto de línea de antes
    scanf(" %c", &opcion_del_menu);
};
