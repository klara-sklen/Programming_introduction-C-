#include <stdio.h>
#include <stdbool.h> // Por que mola usarlo, no tiene más.
#include <math.h>

void imprimeMenu(char *opcion_del_menu);

void opcionCuadrado(float *area, float *perimetro);

void opcionCirculo(float *area, float *perimetro);

void opcionTrianguloEquilatero(float *area, float *perimetro);

int main()
{

    float area = 1, permietro = 0;

    bool el_usuario_ha_solicitado_salir = false;

    while (!el_usuario_ha_solicitado_salir)
    {
        char opcion_del_menu;

        imprimeMenu(&opcion_del_menu);

        switch (opcion_del_menu)
        {
        case 'A':
            opcionCuadrado(&area, &permietro);
            printf("[CUADRADO] El área del cuadrado es: %f.\n", area);
            printf("[CUADRADO] El perímetro del cuadrado es: %f.\n", permietro);
            break;

        case 'B':
            opcionCirculo(&area, &permietro);
            printf("[CÍRCULO] El área del círculo es: %f.\n", area);
            printf("[CÍRCULO] El perímetro del círculo es: %f.\n", permietro);
            break;

        case 'C':
            opcionTrianguloEquilatero(&area, &permietro);
            printf("[TRIÁNGULO EQUILÁTERO] El área del triángulo equilátero es: %f.\n", area);
            printf("[TRIÁNGULO EQUILÁTERO] El perímetro del triángulo equilátero es: %f.\n", permietro);
            break;

        case 'D':
            el_usuario_ha_solicitado_salir = true;
            break;
        }
    }

    return 0;
}

void opcionCuadrado(float *area, float *perimetro)
{
    float lado_cuadrado;

    printf("[CUADRADO] Introduzca el lado del cuadrado:\n");
    scanf("%f", &lado_cuadrado);

    *area = lado_cuadrado * lado_cuadrado;
    *perimetro = 4 * lado_cuadrado;
}

void opcionCirculo(float *area, float *perimetro)
{
    float radio;

    printf("[CÍRCULO] Introduzca el radio del círculo:\n");
    scanf("%f", &radio);

    *area = 3.14 * radio * radio;
    *perimetro = 2 * 3.14 * radio;
}

void opcionTrianguloEquilatero(float *area, float *perimetro)
{
    float lado_triangulo;

    printf("[TRIÁNGULO EQUILÁTERO] Introduzca el lado del triángulo:\n");
    scanf("%f", &lado_triangulo);

    *area = 2 * ((lado_triangulo / 2) * sqrt(pow(lado_triangulo, 2) - pow((lado_triangulo / 2), 2)) / 2);
    *perimetro = 3 * lado_triangulo;
}

void imprimeMenu(char *opcion_del_menu)
{

    *opcion_del_menu = '0';

    printf("¿De qué figura deseas calcular el área y el perímetro?\n");
    printf("A) Cuadrado.\n");
    printf("B) Círculo.\n");
    printf("C) Triángulo equilátero.\n");
    printf("D) Salir del programa.\n");

    // Añadimos el espacio para que no considere el salto de línea de antes
    scanf(" %c", &opcion_del_menu);
}