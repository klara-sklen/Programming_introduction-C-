#include <stdio.h>

void escanearNumeros(int *numero_1, int *numero_2);

void imprimirMenu(int *numero_1, int *numero_2, int *el_usuario_ha_pedido_salir_del_programa);

int calcularPotencia(int numero_1, int numero_2);

int calcularFactorial(int numero);

float calcularCombinatoria(int numero_1, int numero_2);

int main()
{
    int numero_1, numero_2, el_usuario_ha_pedido_salir_del_programa = 0;

    escanearNumeros(&numero_1, &numero_2);

    imprimirMenu(&numero_1, &numero_2, &el_usuario_ha_pedido_salir_del_programa);

    if (el_usuario_ha_pedido_salir_del_programa == 0) {
        imprimirMenu(&numero_1, &numero_2, &el_usuario_ha_pedido_salir_del_programa);
    }

    return 0;
}

void imprimirMenu(int *numero_1, int *numero_2, int *el_usuario_ha_pedido_salir_del_programa)
{

    char opcion_del_menu;
    opcion_del_menu = '0';

    printf("¿Qué operación quieres realizar con los números?\n");
    printf("A) Calcular los factoriales.\n");
    printf("B) Calcular combinatoria.\n");
    printf("C) Calcular potencia.\n");
    printf("D) Salir del programa\n");

    // Añadimos el espacio para que no considere el salto de línea de antes
    scanf(" %c", &opcion_del_menu);

    switch (opcion_del_menu)
    {
    case 'A':

        printf("El factorial del número %d es %d.\n", *numero_1, calcularFactorial(*numero_1));
        printf("El factorial del número %d es %d.\n", *numero_2, calcularFactorial(*numero_2));

        break;

    case 'B':

        if (numero_1 >= numero_2)
        {
            printf("La combinatoria de %d y %d es %f.\n", *numero_1, *numero_2, calcularCombinatoria(*numero_1, *numero_2));
        }
        else
        {
            printf("No se puede calcular la combinatoria de estos números.\n");
        }

        break;

    case 'C':
        printf("La potencia (%d)^(%d) es %d.\n", *numero_1, *numero_2, calcularPotencia(*numero_1, *numero_2));
        break;

    case 'D':
        *el_usuario_ha_pedido_salir_del_programa = 1;
        break;

    default:
        imprimirMenu(numero_1, numero_2, el_usuario_ha_pedido_salir_del_programa);
        break;
    }
}

void escanearNumeros(int *numero_1, int *numero_2)
{
    printf("\nIntroduzca el primer número: ");
    scanf("%d", numero_1);

    printf("\nIntroduzca el segundo número: ");
    scanf("%d", numero_2);
}

float calcularCombinatoria(int numero_1, int numero_2)
{
    return calcularFactorial(numero_1) / (calcularFactorial(numero_2) * calcularFactorial(numero_1 - numero_2));
}

int calcularPotencia(int numero_1, int numero_2)
{
    int potencia = 1;

    while (numero_1 < numero_2)
    {
        potencia = potencia * numero_1;

        numero_2--;
    }

    return potencia;
}

int calcularFactorial(int numero)
{
    // Inicializo en 1 porque es el primer multiplicador distinto de 0
    int factorial = 1;

    for (int puntero = numero; 1 < puntero; puntero--)
    {
        factorial = puntero * factorial;
    }

    return factorial;
}