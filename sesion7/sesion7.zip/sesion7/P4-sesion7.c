#include <stdio.h>

void mostrarPromedio(int numerosPares[], int numerosImpares[]);

void mostrarMaximoMinimo(int numerosPares[], int numerosImpares[]);

void sumarNumeros(int numero_escaneado, int numerosPares[], int numerosImpares[], int *numero_de_numeros_global);

void leerNumeros(int numerosPares[], int numerosImpares[], int *numero_de_numeros_global);

int main()
{
    int numero_de_numeros_global = 0;

    /*
        Definición posiciones vector:

        posición [0] -> refleja el número de pares que se han sumado
        posición [1] -> refleja la sumatoria de los números pares
        posición [2] -> valor máximo introducido
        posición [3] -> posición valor máximo introducido
        posición [4] -> valor mínimo introducido
        posición [5] -> posición valor mínimo introducido
    */

    int numerosPares[6], numerosImpares[6];

    leerNumeros(numerosPares, numerosImpares, &numero_de_numeros_global);

    mostrarPromedio(numerosPares, numerosImpares);
    mostrarMaximoMinimo(numerosPares, numerosImpares);

    return 0;
}

void leerNumeros(int numerosPares[], int numerosImpares[], int *numero_de_numeros_global)
{
    int numero_escaneado = 1;

    printf("Introduzca un número (si desea cerrar el programa, escriba 0).\n");
    scanf("%d", &numero_escaneado);

    if (numero_escaneado != 0)
    {
        (*numero_de_numeros_global)++;
        sumarNumeros(numero_escaneado, numerosPares, numerosImpares, numero_de_numeros_global);

        leerNumeros(numerosPares, numerosImpares, numero_de_numeros_global);
    }
}

/*
    Definición posiciones vector:

    posición [0] -> refleja el número de pares que se han sumado
    posición [1] -> refleja la sumatoria de los números pares
    posición [2] -> valor máximo introducido
    posición [3] -> posición valor máximo introducido
    posición [4] -> valor mínimo introducido
    posición [5] -> posición valor mínimo introducido
*/

void mostrarPromedio(int numerosPares[], int numerosImpares[])
{
    printf("[PROMEDIO] Números pares: %d // Números impares: %d\n", numerosPares[1] / numerosPares[0], numerosImpares[1] / numerosImpares[0]);
}

void mostrarMaximoMinimo(int numerosPares[], int numerosImpares[])
{
    printf("[MÁXIMO] Números pares: %d (posición #%d) // Números impares %d (posición #%d)\n", numerosPares[2], numerosPares[3], numerosImpares[2], numerosImpares[3]);
    printf("[MÍNIMO] Números pares: %d (posición #%d) // Números impares %d (posición #%d)\n", numerosPares[4], numerosPares[5], numerosImpares[4], numerosImpares[5]);
}

void sumarNumeros(int numero_escaneado, int numerosPares[], int numerosImpares[], int *numero_de_numeros_global)
{

    /*
        Definición posiciones vector:

        posición [0] -> número de pares que se han sumado
        posición [1] -> sumatoria de los números pares
        posición [2] -> valor máximo introducido
        posición [3] -> posición valor máximo introducido
        posición [4] -> valor mínimo introducido
        posición [5] -> posición valor mínimo introducido
    */

    if ((numero_escaneado % 2) == 0)
    {

        (numerosPares[0])++;
        numerosPares[1] = numerosPares[1] + numero_escaneado;

        // inicializar valor mínimo
        if (numerosPares[4] == 0 && numerosPares[0] == 1)
        {
            numerosPares[4] = numero_escaneado;
            numerosPares[5] = *numero_de_numeros_global;
        }

        // gestiona el número máximo
        if (numerosPares[2] < numero_escaneado)
        {
            numerosPares[2] = numero_escaneado;
            numerosPares[3] = *numero_de_numeros_global;
        }

        // gestiona el número mínimo
        if (numerosPares[4] > numero_escaneado)
        {
            numerosPares[4] = numero_escaneado;
            numerosPares[5] = *numero_de_numeros_global;
        }
    }
    else
    {
        (numerosImpares[0])++;
        numerosImpares[1] = numerosImpares[1] + numero_escaneado;

        // inicializar valor mínimo
        if (numerosImpares[4] == 0 && numerosImpares[0] == 1)
        {
            numerosImpares[4] = numero_escaneado;
            numerosImpares[5] = *numero_de_numeros_global;
        }

        // gestiona el número máximo
        if (numerosImpares[2] < numero_escaneado)
        {
            numerosImpares[2] = numero_escaneado;
            numerosImpares[3] = *numero_de_numeros_global;
        }

        // gestiona el número mínimo
        if (numerosImpares[4] > numero_escaneado)
        {
            numerosImpares[4] = numero_escaneado;
            numerosImpares[5] = *numero_de_numeros_global;
        }
    }
}